
const navSize = document.querySelectorAll(".nav-size li a");
const tabs__wrap = document.querySelectorAll(".tab__wrap");

navSize.forEach(function (tab, tab_index) {
    tab.addEventListener("click", function () {

        navSize.forEach(function (tab) {
            tab.classList.remove("active");
        })

        tab.classList.add("active");

        tabs__wrap.forEach(function (content, content_index) {
            if (content_index == tab_index) {
                content.style.display = "block";
            }
            else {
                content.style.display = "none";
            }
        })
    })
})