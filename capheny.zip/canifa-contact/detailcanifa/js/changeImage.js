
const onChanges = (id) => {
    const imagesPath = document.getElementById(id).getAttribute('src');
    document.getElementById('imagesChange').setAttribute('src', imagesPath);
}