const tabOppor = document.querySelectorAll(".opportunity-tabs a");
const contentTabs = document.querySelectorAll(".content-tab");

tabOppor.forEach(function (tab, tab_index) {
    tab.addEventListener("click", function () {

        tabOppor.forEach(function (tab) {
            tab.classList.remove("active");
        })

        tab.classList.add("active");

        contentTabs.forEach(function (content, content_index) {
            if (content_index == tab_index) {
                content.style.display = "block";
            }
            else {
                content.style.display = "none";
            }
        })
    })
})